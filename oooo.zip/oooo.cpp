#include <iostream>
#include <iomanip>

using namespace std;

class TrafficManagementSystem {
private:
    int totalCars;
    int totalBikes;
    int totalTrucks;

public:
    TrafficManagementSystem() {
        totalCars = 0;
        totalBikes = 0;
        totalTrucks = 0;
    }

    void addVehicle(int vehicleType) {
        switch (vehicleType) {
            case 1:
                totalCars++;
                break;
            case 2:
                totalBikes++;
                break;
            case 3:
                totalTrucks++;
                break;
            default:
                cout << "Invalid vehicle type!" << endl;
                break;
        }
    }

    void displayStatistics() {
        cout << "Traffic Management System" << endl;
        cout << "-------------------------" << endl;
        cout << "Total Cars: " << totalCars << endl;
        cout << "Total Bikes: " << totalBikes << endl;
        cout << "Total Trucks: " << totalTrucks << endl;
        cout << "-------------------------" << endl;
        cout << "Total Vehicles: " << totalCars + totalBikes + totalTrucks << endl;
    }
};

int main() {
    TrafficManagementSystem tms;
    int choice;

    do {
        cout << "Traffic Management System Menu" << endl;
        cout << "-------------------------------" << endl;
        cout << "1. Add Car" << endl;
        cout << "2. Add Bike" << endl;
        cout << "3. Add Truck" << endl;
        cout << "4. Display Statistics" << endl;
        cout << "5. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                tms.addVehicle(1);
                cout << "Car added successfully!" << endl;
                break;
            case 2:
                tms.addVehicle(2);
                cout << "Bike added successfully!" << endl;
                break;
            case 3:
                tms.addVehicle(3);
                cout << "Truck added successfully!" << endl;
                break;
            case 4:
                tms.displayStatistics();
                break;
            case 5:
                cout << "Exiting..." << endl;
                break;
            default:
                cout << "Invalid choice!" << endl;
                break;
        }

        cout << endl;
    } while (choice != 5);

    return 0;
}

#include<iostream>
using namespace std;

int main(){
    string color;
    cout<<"Enter The color of light: "<<endl;
    cin>>color;
    
    if(color == "Red" || color == "red"){
        cout<<"Stop"<<endl;
    }
    else if(color == "Yellow" || color == "yellow"){
        cout<<"Wait"<<endl;
    }
    else if(color == "Green" || color == "green"){
        cout<<"Go"<<endl;
    }
    else{
        cout<<"Invalid input"<<endl;
    }
    
    return 0;
}
